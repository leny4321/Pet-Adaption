-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 21, 2024 at 10:34 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pet`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_message`
--

CREATE TABLE `tbl_message` (
  `id` int(255) NOT NULL,
  `sender` varchar(255) NOT NULL,
  `reciever` varchar(255) NOT NULL,
  `msgID` varchar(255) NOT NULL,
  `postID` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_message`
--

INSERT INTO `tbl_message` (`id`, `sender`, `reciever`, `msgID`, `postID`, `message`, `date`, `owner`) VALUES
(4, '733631', '119372', '147187', '760875', 'Sample message to the owner of sting', '2024-04-21', 'Sonny Boye Vesoza Ellema'),
(5, '733631', '119372', '352866', '760875', 'Second Message for Sting, Hello There !', '2024-04-21', 'Sonny Boye Vesoza Ellema'),
(6, '119372', '119372', '940077', '760875', 'Hi There, Good Afternoon, Still Interested?', '2024-04-21', 'Sonny Boye Vesoza Ellema'),
(7, '119372', '119372', '747916', '760875', 'Message me at insta hihi', '2024-04-21', 'Sonny Boye Vesoza Ellema'),
(8, '119372', '733631', '868377', '504261', 'Hi There !', '2024-04-21', 'Jerson Versoza Nieva'),
(9, '733631', '119372', '518367', '760875', '', '2024-04-21', 'Sonny Boye Vesoza Ellema');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_post`
--

CREATE TABLE `tbl_post` (
  `id` int(255) NOT NULL,
  `postId` varchar(255) NOT NULL,
  `petName` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `ownerID` varchar(255) NOT NULL,
  `bod` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `pic` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_post`
--

INSERT INTO `tbl_post` (`id`, `postId`, `petName`, `owner`, `ownerID`, `bod`, `date`, `pic`, `description`, `status`) VALUES
(19, '760875', 'Sting', 'Sonny Boye Vesoza Ellema', '119372', '2024-04-01', '2024-04-21', 'cat.jpg', 'Sting the Cat, 1 month Old', '1'),
(20, '504261', 'Clint', 'Jerson Versoza Nieva', '733631', '2024-03-01', '2024-04-21', 'AA.png', 'Clint is a 1 and a half month old parrot', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `f_name` varchar(255) NOT NULL,
  `m_name` varchar(255) NOT NULL,
  `l_name` varchar(255) NOT NULL,
  `bod` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phoneNum` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `frontID` varchar(255) NOT NULL,
  `backID` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `user_id`, `f_name`, `m_name`, `l_name`, `bod`, `email`, `address`, `phoneNum`, `username`, `password`, `user_type`, `status`, `frontID`, `backID`) VALUES
(6, '129647', 'Aeron', 'Carl', 'Arididon', '1999-08-27', 'aeroncarlarididon@gmail.com', 'Brgy. 03', '09634974554', 'admin', '$2y$10$qQVvEy.zrqy59cTc0qTFauazjbu5wJHJl2VvBQRyo/LPWHMBAzHcu', '1', '1', 'AA.png', 'clark-tibbs-oqStl2L5oxI-unsplash.jpg'),
(9, '733631', 'Jerson', 'Versoza', 'Nieva', '1999-06-02', 'Jerson@gmail.com', 'Brgy. Maulong', '09634974554', 'zach', '$2y$10$ejE9QJKwFmHyeh.ljQ1FO.zLH5fnf8vjIfrKs.PVp6xGqIV6Q9NnW', '2', '1', '1.jpg', '2.jpg'),
(10, '119372', 'Sonny Boye', 'Vesoza', 'Ellema', '1994-03-23', 'sonn@gmail.com', 'Daram, Samar', '09634974554', 'sonn', '$2y$10$Dr4v.cd7OMRTxJSqAntiH.9yl22TMx96EMthfIb6/Q3zERqZez5vG', '2', '1', 'clark-tibbs-oqStl2L5oxI-unsplash.jpg', 'AA.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_message`
--
ALTER TABLE `tbl_message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_post`
--
ALTER TABLE `tbl_post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_message`
--
ALTER TABLE `tbl_message`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_post`
--
ALTER TABLE `tbl_post`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
