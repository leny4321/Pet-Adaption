<!DOCTYPE html>
<html dir="ltr" lang="en">

<?php include './includes/head.php' ?>
<?php include './code.php' ?>

<body>
    <div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full"
        data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">

        <?php include 'includes/header.php'; ?>

        <?php include './includes/sidebar.php'; ?>

        <div class="page-wrapper">
            <div class="page-breadcrumb">
                <div class="row align-items-center">
                    <div class="col-md-6 col-8 align-self-center">
                        <h3 class="page-title mb-0 p-0">Client Settings</h3>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Client Settings</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>



            <div class="container-fluid">
                <div class="row">
                    <!-- Column -->
                    <?php 
                        $UiD = $_SESSION['user_id'];
                        $sqlUser = $conn->query("SELECT * FROM tbl_user WHERE user_id = '$UiD' ");
                        $rowUser = mysqli_fetch_object($sqlUser);
                    ?>
                    <div class="col-lg-7 col-xlg-3 col-md-5">
                        <div class="card">
                            <div class="card-body profile-card">
                                <center class=""> <img src="./uploads/<?php echo $rowUser->pPic;?>" class="" width="250" style="border-radius: 50%"/>
                                    <h4 class="card-title mt-2">Display Picture</h4>
                                </center>
                            </div>
                            <div class="card-body profile-card">
                                <center class="mt-4"> <img src="./uploads/<?php echo $rowUser->frontID;?>" class="" width="100%" />
                                    <h4 class="card-title mt-2">Front ID</h4>
                                </center>
                                <center class="mt-4"> <img src="./uploads/<?php echo $rowUser->backID;?>" class="" width="100%" />
                                    <h4 class="card-title mt-2">Back ID</h4>
                                </center>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-5 col-xlg-9 col-md-7">
                        <div class="card">
                            <div class="card-body">
                                <form class="form-horizontal form-material mx-2">
                                    <div class="form-group">
                                        <label class="col-md-12 mb-0">User ID</label>
                                        <div class="col-md-12">
                                            <input type="text" readonly placeholder="<?php echo $_SESSION['user_id']; ?>"
                                                class="form-control ps-0 form-control-line">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12 mb-0">Name</label>
                                        <div class="col-md-12">
                                            <input type="text" readonly placeholder="<?php echo $_SESSION['user_fname']; ?>"
                                                class="form-control ps-0 form-control-line">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="example-email" class="col-md-12">Email</label>
                                        <div class="col-md-12">
                                            <input type="email" readonly placeholder="<?php echo $_SESSION['email']; ?>"
                                                class="form-control ps-0 form-control-line" name="example-email"
                                                id="example-email">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12 mb-0">Phone No</label>
                                        <div class="col-md-12">
                                            <input type="text" readonly placeholder="<?php echo $_SESSION['phoneNum']; ?>"
                                                class="form-control ps-0 form-control-line">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="example-email" class="col-md-12">Address</label>
                                        <div class="col-md-12">
                                            <input type="email" readonly placeholder="<?php echo $_SESSION['address']; ?>"
                                                class="form-control ps-0 form-control-line" name="example-email"
                                                id="example-email">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-sm-12 d-flex">
                                            <!-- <button class="btn btn-success mx-auto mx-md-0 text-white px-3">Update</button> -->
                                            <!-- <button class="btn btn-danger mx-auto mx-md-2 text-white">Delete Account</button> -->
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="./assets/plugins/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="./assets/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/app-style-switcher.js"></script>
    <!--Wave Effects -->
    <script src="js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="js/custom.js"></script>
</body>

</html>