<?php 
	include './code.php';

	$userID = $_SESSION['user_id'];
	$chck_user = $conn->query("SELECT * FROM tbl_user WHERE user_id = '$userID' ");
	if($result = mysqli_num_rows($chck_user) > 0){
?>

    <!DOCTYPE html>
    <html dir="ltr" lang="en">

    <?php include './includes/head.php' ?>

    <?php
        $user_type = $_SESSION['user_type'];
        if($user_type === '1'){
    ?>

        <body>
            <div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full"
                data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">

                <?php include 'includes/header.php'; ?>

                <?php include './includes/sidebar.php'; ?>

                <div class="page-wrapper">
                    <div class="page-breadcrumb">
                        <div class="row align-items-center">
                            <div class="col-md-6 col-8 align-self-center">
                                <h3 class="page-title mb-0 p-0">Post to Approve</h3>
                                <div class="d-flex align-items-center">
                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">Post to Approve</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="container-fluid">
                        <div class="row">

                            <?php
                                if (isset($_SESSION['postID']) && $_SESSION['postID'] != '') {
                                    $pID = $_SESSION['postID'];
                                    $sqlUser = $conn->query("SELECT * FROM tbl_post WHERE postId = '$pID' ");
                                    $rowUser = mysqli_fetch_object($sqlUser);
                            ?>
                                    <div class="row">
                                        <div class="col-lg-7 col-xlg-3 col-md-5">
                                            <div class="card">
                                                <div class="card-body profile-card">
                                                    <center class="mt-4"> <img src="./uploads/<?php echo $rowUser->pic;?>" class="" width="250" />
                                                        <h4 class="card-title mt-3"><?php echo $rowUser->petName;?></h4>
                                                    </center>
                                                </div>
                                                <hr>
                                                <div class="card-body profile-card">
                                                    <center class="mt-4"> <img src="./uploads/<?php echo $rowUser->petCert;?>" class="" width="100%" />
                                                        <h4 class="card-title mt-3"><?php echo $rowUser->petName;?> Certificate</h4>
                                                    </center>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-5 col-xlg-9 col-md-7">
                                            <div class="card">
                                                <div class="card-body">
                                                    <form class="form-horizontal form-material mx-2" action='code.php' method='POST'>
                                                        <div class="form-group">
                                                            <label class="col-md-12 mb-0">Owner</label>
                                                            <div class="col-md-12">
                                                                <input type="text" readonly placeholder="<?php echo $rowUser->owner; ?>"
                                                                    class="form-control ps-0 form-control-line">
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="col-md-12 mb-0">Vaccinated</label>
                                                            <div class="col-md-12">
                                                                <input type="text" readonly placeholder="<?php echo $rowUser->vacc; ?>"
                                                                    class="form-control ps-0 form-control-line">
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="example-email" class="col-md-12">Pet Birthday</label>
                                                            <div class="col-md-12">
                                                                <input type="email" readonly placeholder="<?php echo $rowUser->bod; ?>"
                                                                    class="form-control ps-0 form-control-line" name="example-email"
                                                                    id="example-email">
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="col-md-12 mb-0">Date Posted</label>
                                                            <div class="col-md-12">
                                                                <input type="text" readonly placeholder="<?php echo $rowUser->date; ?>"
                                                                    class="form-control ps-0 form-control-line">
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="example-email" class="col-md-12">Description</label>
                                                            <div class="col-md-12">
                                                                <input type="email" readonly placeholder="<?php echo $rowUser->description; ?>"
                                                                    class="form-control ps-0 form-control-line" name="example-email"
                                                                    id="example-email">
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="col-sm-12 d-flex">
                                                                <input value="<?php echo $rowUser->postId; ?>" type='hidden' name='pid'/>
                                                                
                                                                <input class="btn btn-success mx-auto mx-md-0 text-white" value='Approve' type='submit' name='btnApprove_post'/>
                                                                <input class="btn btn-danger mx-auto mx-md-2 text-white" value='Decline' type='submit' name='btnDecline_post'/>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            <?php
                                }else if(isset($_SESSION['viewPost']) && $_SESSION['viewPost'] != ''){
                                    $pID = $_SESSION['viewPost'];
                                    $sqlUser = $conn->query("SELECT * FROM tbl_post WHERE postId = '$pID' ");
                                    $rowUser = mysqli_fetch_object($sqlUser);
                            ?>
                                    <div class="row">
                                        <div class="col-lg-7 col-xlg-3 col-md-5">
                                            <div class="card">
                                                <div class="card-body profile-card">
                                                    <center class="mt-4"> <img src="./uploads/<?php echo $rowUser->pic;?>"
                                                            class="" width="250" />
                                                        <h4 class="card-title mt-3"><?php echo $rowUser->petName;?></h4>
                                                    </center>
                                                </div>
                                                <hr>
                                                <div class="card-body profile-card">
                                                    <center class="mt-4"> <img src="./uploads/<?php echo $rowUser->petCert;?>" class="" width="100%" />
                                                        <h4 class="card-title mt-3"><?php echo $rowUser->petName;?> Certificate</h4>
                                                    </center>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-5 col-xlg-9 col-md-7">
                                            <div class="card">
                                                <div class="card-body">
                                                    <form class="form-horizontal form-material mx-2" action='code.php' method='POST'>
                                                        <div class="form-group">
                                                            <label class="col-md-12 mb-0">Owner</label>
                                                            <div class="col-md-12">
                                                                <input type="text" readonly placeholder="<?php echo $rowUser->owner; ?>"
                                                                    class="form-control ps-0 form-control-line">
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="col-md-12 mb-0">Vaccinated</label>
                                                            <div class="col-md-12">
                                                                <input type="text" readonly placeholder="<?php echo $rowUser->vacc; ?>"
                                                                    class="form-control ps-0 form-control-line">
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="example-email" class="col-md-12">Pet Birthday</label>
                                                            <div class="col-md-12">
                                                                <input type="email" readonly placeholder="<?php echo $rowUser->bod; ?>"
                                                                    class="form-control ps-0 form-control-line" name="example-email"
                                                                    id="example-email">
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="col-md-12 mb-0">Date Posted</label>
                                                            <div class="col-md-12">
                                                                <input type="text" readonly placeholder="<?php echo $rowUser->date; ?>"
                                                                    class="form-control ps-0 form-control-line">
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="example-email" class="col-md-12">Description</label>
                                                            <div class="col-md-12">
                                                                <input type="email" readonly placeholder="<?php echo $rowUser->description; ?>"
                                                                    class="form-control ps-0 form-control-line" name="example-email"
                                                                    id="example-email">
                                                            </div>
                                                        </div>
                                                    </form>
                                                    <button onClick="window.location.reload();" class="btn btn-info mx-auto mx-md-0 text-white">Back</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            <?php
                                }else{
                            ?>	
                                    <div class="col-sm-12">
                                        <div class="card">
                                            <div class="card-body">
                                                <h4 class="card-title mb-3">Post Request List</h4>
                                                <div class="table-responsive">
                                                    
                                                    <table id="myTable_1" class="table table-striped">
                                                        <thead>
                                                            <tr>
                                                                <th class='p-4'>Post ID</th>
                                                                <th class='p-4'>Pet name</th>
                                                                <th class='p-4'>Owner</th>
                                                                <th class='p-4'>Status</th>
                                                                <th class='p-4'>Date</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                        <?php

                                                        // SQL query
                                                        $sql = "SELECT * FROM tbl_post ";
                                                        $result = $conn->query($sql);

                                                        if ($result->num_rows > 0) {
                                                            while($row = $result->fetch_assoc()) {
                                                                echo "<tr>";
                                                                    echo "<td class='p-4'>".$row["postId"]."</td>";
                                                                    echo "<td class='p-4'>".$row["petName"]."</td>";
                                                                    echo "<td class='p-4'>".$row["owner"]."</td>";
                                                                    echo "<td class='p-4'>";
                                                                            if($row['status'] === '1'){
                                                                                echo "Approved / Posted";
                                                                            }else if($row['status'] === '4'){
                                                                                echo "Pending";
                                                                            }else if($row['status'] === '3'){
                                                                                echo "Hidden";
                                                                            }else{
                                                                                echo "Declined";
                                                                            }
                                                                    echo "</td>";
                                                                    echo "<td class='p-4'>";
                                                                            if($row['status'] === '1'){
                                                        ?>
                                                                                <form action='code.php' method='POST'>
                                                                                    <input type='hidden' value="<?php echo $row["postId"]; ?>" name='viewPost'>

                                                                                    <input type='submit' value='View Post' name='btnViewPost' class='col-md-6 btn btn-success p-2 text-white'>
                                                                                </form>
                                                        <?php
                                                                            }else if($row['status'] === '4'){
                                                        ?>
                                                                                <form action='code.php' method='POST'>
                                                                                    <input type='hidden' value="<?php echo $row["postId"]; ?>" name='postID'>

                                                                                    <input type='submit' value='View Pending Post' name='btnPostReq' class='col-md-6 btn btn-danger p-2 text-white'>
                                                                                </form>
                                                        <?php
                                                                            }else if($row['status'] === '3'){
                                                                                echo "Hidden";
                                                                            }else{
                                                                                echo "Declined";
                                                                            }
                                                                    echo "</td>";
                                                                echo "</tr>";
                                                            }
                                                        }
                                                        ?>
                                                        </tbody>
                                                    </table> 
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            <?php }unset($_SESSION['postID']); unset($_SESSION['viewPost']) ?>
                        </div>
                    </div>


                </div>
            </div>

            <script src="./assets/plugins/jquery/dist/jquery.min.js"></script>
            <!-- Bootstrap tether Core JavaScript -->
            <script src="./assets/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
            <script src="js/app-style-switcher.js"></script>
            <!--Wave Effects -->
            <script src="js/waves.js"></script>
            <!--Menu sidebar -->
            <script src="js/sidebarmenu.js"></script>
            <!--Custom JavaScript -->
            <script src="js/custom.js"></script>

            <link href="https://cdn.datatables.net/1.13.3/css/jquery.dataTables.min.css"  rel='stylesheet'>
            <script src="https://cdn.datatables.net/1.13.3/js/jquery.dataTables.min.js"></script>  
            
            <script>
                $(document).ready(function() {
                    $('#myTable_1').DataTable();
                });
            </script>

        </body>

    <?php }else if($user_type === '2'){ ?>

        <body>
            <div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full" data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">

                <?php include 'includes/header.php'; ?>

                <?php include './includes/sidebar.php'; ?>

                <div class="page-wrapper">
                    <div class="page-breadcrumb">
                        <div class="row align-items-center">
                            <div class="col-md-6 col-8 align-self-center">
                                <h3 class="page-title mb-0 p-0">Post to Status</h3>
                                <div class="d-flex align-items-center">
                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">Post Status</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="container-fluid">
                        <div class="row">

                        <?php 
                            $fullName = $_SESSION['user_fname'];
                            $chck_user = $conn->query("SELECT * FROM tbl_post WHERE owner = '$fullName' ");
                            if($result = mysqli_num_rows($chck_user) > 0){

                                while($row = mysqli_fetch_object($chck_user)){
                        ?>
                                <div class="col-lg-4 col-xlg-3 col-md-5">
                                    <div class="card">
                                        <div class="card-body profile-card">
                                            <center class="mt-4"> <img src="./uploads/<?php echo $row->pic; ?>" class="" width="200" />
                                                <h4 class="card-title mt-2 text-danger">
                                                    <?php 
                                                        if($row->status === '4'){
                                                            echo "<h3 class='text-warning'> Pending </h3>";
                                                        }else if($row->status === '1'){
                                                            echo "<h3 class='text-success'> Approved / Posted </h3>";
                                                        }else if($row->status === '3'){
                                                            echo "<h3 class='text-info'> Post Hidden </h3>";
                                                        }else{
                                                            echo "<h3 class='text-danger'> Declined </h3>";
                                                        }
                                                    ?>
                                                </h4>
                                                <h4 class="card-title mt-2"><?php echo $row->petName; ?></h4>
                                                <h6 class="card-subtitle"><?php echo $row->bod; ?></h6>
                                            </center>

                                            <?php 
                                                if($row->status === '1'){
                                            ?>

                                                <form action="code.php" method='POST'>
                                                    <select class="form-select text-center" required name="postStat" aria-label="Default select example">
                                                        <option value=''>Update Post</option>
                                                        <option value="3">Hide Post</option>
                                                        <option value="1">Show Post</option>
                                                    </select>
                                                    <input type="hidden" value="<?php echo $row->postId; ?>" name='postoUpdate'>

                                                    <input type="submit" class='col-md-12 btn btn-info mt-2 text-white' value="Submit Update" name='btnPostUpdate'>
                                                </form>
                                            
                                            <?php }else if($row->status === '3'){
                                            ?>
                                                <form action="code.php" method='POST'>
                                                    <select class="form-select text-center" required name="postStat" aria-label="Default select example">
                                                        <option value=''>Update Post</option>
                                                        <option value="3">Hide Post</option>
                                                        <option value="1">Show Post</option>
                                                    </select>
                                                    <input type="hidden" value="<?php echo $row->postId; ?>" name='postoUpdate'>

                                                    <input type="submit" class='col-md-12 btn btn-info mt-2 text-white' value="Submit Update" name='btnPostUpdate'>
                                                </form>
                                            <?php } ?>


                                        </div>
                                    </div>
                                </div>
                                

                        <?php  } ?>

                                <div class="col-lg-4 col-xlg-3 col-md-5">
                                    <div class="card ">
                                        <div class="card-body profile-card">
                                            <input type="submit" class='col-md-12 p-5 btn btn-info' value="+" style="font-size: 13.5rem; width: 100%; border: none;" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                        </div>
                                    </div>
                                </div>
                        <?php

                            }else{ ?>

                                <div class="col-lg-4 col-xlg-3 col-md-5">
                                    <div class="card ">
                                        <div class="card-body profile-card">
                                            <input type="submit" class='col-md-12 p-5 btn btn-info' value="+" style="font-size: 13.5rem; width: 100%; border: none;" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                        </div>
                                    </div>
                                </div>

                        <?php } ?>

                        </div>
                    </div>

                </div>
            </div>

            
            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <form method="POST" action="code.php" enctype="multipart/form-data">
                            <div class="modal-body">
                                <h2 class="text-center p-3">Fill out the ask information.</h2>
                                    <div class="row">
                                        <div class="col-12 mb-3">
                                            <input type="text" class="form-control" value="<?php echo $_SESSION['user_fname']; ?>" aria-label="First name" name="owerName" readonly>
                                        </div>
                                        <div class="col-12 mb-3">
                                            <input type="text" class="form-control" placeholder="Pet name" aria-label="First name" name="petName" required>
                                        </div>
                                        <div class="col-12 mb-3">
                                            <input type="date" class="form-control" placeholder="Birthdate" aria-label="First name" name="bod" required>
                                        </div>
                                        <div class="col-12 mb-3">
                                            <select class="form-select text-center" required name="vacc" aria-label="Default select example">
                                                <option selected>--- Vaccinated ---</option>
                                                <option value="NO">NO</option>
                                                <option value="YES">YES</option>
                                            </select>
                                        </div>

                                        <hr>
                                            <div class="mb-3">
                                                <h4 for="inputPassword6" class="col-form-label">Pet Profile</h4>
                                                <div class="">
                                                    <input type="file" id="inputPassword6" class="form-control" placeholder="Picture" aria-label="First name" name="petPic" required>
                                                </div>
                                            </div>
                                        <hr>
                                            <div class="mb-3">
                                                <h4 for="inputPassword6" class="col-form-label">Pet Certificate</h4>
                                                <div class="">
                                                    <input type="file" id="inputPassword6" class="form-control" placeholder="Picture" aria-label="First name" name="petCert" required>
                                                </div>
                                            </div>
                                        <hr>

                                        <div class="form-group">
                                            <label class="col-md-12 mb-0">Pet Description</label>
                                            <div class="col-md-12">
                                                <textarea rows="5" name='description' class="form-control ps-0 form-control-line"></textarea>
                                            </div>
                                        </div>
                                    </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <input type="submit" class="btn btn-primary" value="Submit" name="btn_reqPost"/>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <script src="./assets/plugins/jquery/dist/jquery.min.js"></script>
            <!-- Bootstrap tether Core JavaScript -->
            <script src="./assets/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
            <script src="js/app-style-switcher.js"></script>
            <!--Wave Effects -->
            <script src="js/waves.js"></script>
            <!--Menu sidebar -->
            <script src="js/sidebarmenu.js"></script>
            <!--Custom JavaScript -->
            <script src="js/custom.js"></script>
        </body>

    <?php } ?>
    

    </html>

<?php 
	}else{
		?>
			<script>
				alert('<?php echo "Please login first !"; ?>');
				window.location.href="login.php"; 
			</script>                
		<?php
	}
?>