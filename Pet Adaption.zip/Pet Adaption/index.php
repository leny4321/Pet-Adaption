<?php 
	include './code.php';

	$userID = $_SESSION['user_id'];
	$chck_user = $conn->query("SELECT * FROM tbl_user WHERE user_id = '$userID' ");
	if($result = mysqli_num_rows($chck_user) > 0){
?>

    <!DOCTYPE html>
    <html dir="ltr" lang="en">

    <?php include './includes/head.php' ?>
    
    <?php
        $user_type = $_SESSION['user_type'];
        if($user_type === '1'){
    ?>

        <body>
            <div id="main-wrapper" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full"
                data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">

                <?php include 'includes/header.php'; ?>

                <?php include './includes/sidebar.php'; ?>

                <div class="page-wrapper">
                    <div class="page-breadcrumb">
                        <div class="row align-items-center">
                            <div class="col-md-6 col-8 align-self-center">
                                <h3 class="page-title mb-0 p-0">Welcome Admin</h3>
                                <div class="d-flex align-items-center">
                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-3">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title fs-3">Users</h4>
                                        <div class="text-end">
                                            <?php 
                                                $sqlUser = $conn->query("SELECT COUNT(*) as ttlUser FROM tbl_user WHERE user_type = '2' AND status = '1' ");
                                                $rowUser = mysqli_fetch_object($sqlUser);
                                            ?>
                                            <h2 class="font-light mb-0"><i class="ti-check text-success"></i> <?php echo $rowUser->ttlUser; ?></h2>
                                            <span class="text-muted">Total Users</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title fs-3">User to Approve</h4>
                                        <div class="text-end">
                                            <?php 
                                                $sqlUserApp = $conn->query("SELECT COUNT(*) as ttlUserApp FROM tbl_user WHERE user_type = '2' AND status = '0' ");
                                                $rowApp = mysqli_fetch_object($sqlUserApp);
                                            ?>
                                            <h2 class="font-light mb-0"><i class="ti-unlock text-info"></i> <?php echo $rowApp->ttlUserApp; ?></h2>
                                            <span class="text-muted">Total User to Approve</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title fs-3">Post to Approve</h4>
                                        <div class="text-end">
                                            <?php 
                                                $sqlPostApp = $conn->query("SELECT COUNT(*) as ttlpostApp FROM tbl_post WHERE status = '0' ");
                                                $rowPost = mysqli_fetch_object($sqlPostApp);
                                            ?>
                                            <h2 class="font-light mb-0"><i class="ti-agenda text-info"></i> <?php echo $rowPost->ttlpostApp; ?></h2>
                                            <span class="text-muted">Total Post to Approve</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title fs-3">Admin</h4>
                                        <div class="text-end">
                                            <?php 
                                                $sqlAdmin = $conn->query("SELECT COUNT(*) as ttlAdmin FROM tbl_user WHERE status = '1' AND user_type = '1' ");
                                                $rowAdmin = mysqli_fetch_object($sqlAdmin);
                                            ?>
                                            <h2 class="font-light mb-0"><i class="ti-user text-info"></i> <?php echo $rowAdmin->ttlAdmin; ?></h2>
                                            <span class="text-muted">Total Admin</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php 
                            if(isset($_SESSION['viewFeed']) && $_SESSION['viewFeed'] != ''){
                                $pID = $_SESSION['viewFeed'];
                                $sqlUser = $conn->query("SELECT * FROM tbl_post WHERE postId = '$pID' ");
                                $rowUser = mysqli_fetch_object($sqlUser);
                        ?>
                            <div class="row">
                                <div class="col-lg-4 col-xlg-3 col-md-5">
                                    <div class="card">
                                        <div class="card-body profile-card">
                                            <center class="mt-4"> <img src="./uploads/<?php echo $rowUser->pic;?>"
                                                    class="" width="250" />
                                                <h4 class="card-title mt-3"><?php echo $rowUser->petName;?></h4>
                                            </center>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-8 col-xlg-9 col-md-7">
                                    <div class="card">
                                        <div class="card-body">
                                            <form class="form-horizontal form-material mx-2" action='code.php' method='POST'>
                                                <div class="form-group">
                                                    <label class="col-md-12 mb-0">Owner</label>
                                                    <div class="col-md-12">
                                                        <input type="text" readonly placeholder="<?php echo $rowUser->owner; ?>"
                                                            class="form-control ps-0 form-control-line">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="example-email" class="col-md-12">Pet Birthday</label>
                                                    <div class="col-md-12">
                                                        <input type="email" readonly placeholder="<?php echo $rowUser->bod; ?>"
                                                            class="form-control ps-0 form-control-line" name="example-email"
                                                            id="example-email">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-12 mb-0">Date Posted</label>
                                                    <div class="col-md-12">
                                                        <input type="text" readonly placeholder="<?php echo $rowUser->date; ?>"
                                                            class="form-control ps-0 form-control-line">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="example-email" class="col-md-12">Description</label>
                                                    <div class="col-md-12">
                                                        <input type="email" readonly placeholder="<?php echo $rowUser->description; ?>"
                                                            class="form-control ps-0 form-control-line" name="example-email"
                                                            id="example-email">
                                                    </div>
                                                </div>
                                            </form>
                                            <button onClick="window.location.reload();" class="btn btn-info mx-auto mx-md-0 text-white">Back</button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        <?php }else { ?>

                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <h4 class="card-title">Feed</h4>
                                                <div class="container-fluid">
                                                    <div class="row">

                                                        <?php 
                                                            $chck_user = $conn->query("SELECT * FROM tbl_post where status = '1' ");
                                                            if($result = mysqli_num_rows($chck_user) > 0){

                                                                while($row = mysqli_fetch_object($chck_user)){
                                                        ?>
                                                                <div class="col-lg-4 col-xlg-3 col-md-5">
                                                                    <div class="card">
                                                                        <div class="card-body profile-card">
                                                                            <center class=""> <img src="./uploads/<?php echo $row->pic; ?>"
                                                                                    class="" width="200" />
                                                                                    <form action="code.php" method='POST' class='mt-3'>
                                                                                        <input type="hidden" value="<?php echo $row->postId; ?>" name='viewFeed'>

                                                                                        <input type="submit" value='View Description' name='btnView' class='col-md-12 btn btn-info p-2 text-white'>
                                                                                    </form>
                                                                            </center>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                        <?php  } 

                                                            }else{ ?>

                                                                <div class="col-lg-12 col-xlg-3 col-md-5">
                                                                    <div class="card ">
                                                                        <div class="card-body profile-card">
                                                                            <input type="text" readonly class='col-md-12 p-5 btn btn-white' value="No Post Yet !" style="font-size: 2rem; width: 100%; border: none;">
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                        <?php } ?>

                                                    </div>
                                                </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        <?php } unset($_SESSION['viewFeed']); ?>

                    </div>
                </div>
            </div>


            <script src="./assets/plugins/jquery/dist/jquery.min.js"></script>
            <!-- Bootstrap tether Core JavaScript -->
            <script src="./assets/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
            <script src="js/app-style-switcher.js"></script>
            <!--Wave Effects -->
            <script src="js/waves.js"></script>
            <!--Menu sidebar -->
            <script src="js/sidebarmenu.js"></script>
            <!--Custom JavaScript -->
            <script src="js/custom.js"></script>
            <!--This page JavaScript -->
            <!--flot chart-->
            <script src="./assets/plugins/flot/jquery.flot.js"></script>
            <script src="./assets/plugins/flot.tooltip/js/jquery.flot.tooltip.min.js"></script>
            <script src="js/pages/dashboards/dashboard1.js"></script>
        </body>

    <?php }else if($user_type === '2'){ ?>

        <body>
            <div id="main-wrapper" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full"
                data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">

                <?php include 'includes/header.php'; ?>

                <?php include './includes/sidebar.php'; ?>

                <div class="page-wrapper">
                    <div class="page-breadcrumb">
                        <div class="row align-items-center">
                            <div class="col-md-6 col-8 align-self-center">
                                <h3 class="page-title mb-0 p-0">Welcome User</h3>
                                <div class="d-flex align-items-center">
                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                        <?php 
                            if(isset($_SESSION['viewFeed']) && $_SESSION['viewFeed'] != ''){
                                $post_ID = $_SESSION['viewFeed'];
                                $sqlUser = $conn->query("SELECT * FROM tbl_post WHERE postId = '$post_ID' ");
                                $rowUser = mysqli_fetch_object($sqlUser);
                        ?>
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-lg-4 col-xlg-3 col-md-5">
                                        <div class="card">
                                            <div class="card-body profile-card">
                                                <center class="mt-4"> <img src="./uploads/<?php echo $rowUser->pic;?>"
                                                        class="" width="250" />
                                                    <h4 class="card-title mt-3"><?php echo $rowUser->petName;?></h4>
                                                </center>
                                            </div>
                                        </div>
                                    </div>
                                    <style>
                                        .container {
                                            max-width: 600px;
                                            margin: auto;
                                            padding: 20px;
                                        }
                                        .message {
                                            padding: 10px;
                                            margin-bottom: 10px;
                                            border-radius: 10px;
                                        }
                                        .message.sender {
                                            background-color: #DCF8C6;
                                            text-align: right;
                                            display: flex;
                                            justify-content: space-between;
                                            align-items: center;
                                        }
                                        .message.receiver {
                                            background-color: #EAEAEA;
                                            display: flex;
                                            justify-content: space-between;
                                            align-items: center;
                                        }
                                    </style>
                                    <div class="col-lg-8 col-xlg-9 col-md-7">
                                        <div class="card">
                                            <div class="card-body">

                                                <ul class="nav nav-tabs" id="myTab" role="tablist">
                                                    <li class="nav-item" role="presentation">
                                                        <button class="nav-link active btn btn-outline-light text-dark" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">Description</button>
                                                    </li>
                                                    <li class="nav-item" role="presentation">
                                                        <button class="nav-link btn btn-outline-light text-dark" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Message</button>
                                                    </li>
                                                </ul>
                                                <div class="tab-content" id="myTabContent">
                                                    <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                                        <form class="form-horizontal form-material mx-2 mt-4" action='code.php' method='POST'>
                                                            <div class="form-group">
                                                                <label class="col-md-12 mb-0">Owner</label>
                                                                <div class="col-md-12">
                                                                    <input type="text" readonly placeholder="<?php echo $rowUser->owner; ?>"
                                                                        class="form-control ps-0 form-control-line">
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="col-md-12 mb-0">Vaccianted</label>
                                                                <div class="col-md-12">
                                                                    <input type="text" readonly placeholder="<?php echo $rowUser->vacc; ?>"
                                                                        class="form-control ps-0 form-control-line">
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="example-email" class="col-md-12">Pet Birthday</label>
                                                                <div class="col-md-12">
                                                                    <input type="email" readonly placeholder="<?php echo $rowUser->bod; ?>"
                                                                        class="form-control ps-0 form-control-line" name="example-email"
                                                                        id="example-email">
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="col-md-12 mb-0">Date Posted</label>
                                                                <div class="col-md-12">
                                                                    <input type="text" readonly placeholder="<?php echo $rowUser->date; ?>"
                                                                        class="form-control ps-0 form-control-line">
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="col-md-12 mb-0">Certificate</label>
                                                                <div class="col-md-12">
                                                                    <img src="./uploads/<?php echo $rowUser->petCert; ?>" class="img-fluid" alt="...">
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="example-email" class="col-md-12">Description</label>
                                                                <div class="col-md-12">
                                                                    <input type="email" readonly placeholder="<?php echo $rowUser->description; ?>"
                                                                        class="form-control ps-0 form-control-line" name="example-email"
                                                                        id="example-email">
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <div class="col-sm-12 d-flex">
                                                                    <input value="<?php echo $pID ?>" type='hidden' name='postID'/>
                                                                    
                                                                    <!-- <input class="btn btn-success mx-auto mx-md-0 text-white" value='Adopt' type='submit' name='btnAdopt'/> -->
                                                                    <input type='button' onClick="window.location.reload();" value='Back' class="btn btn-warning mx-auto mx-md-0 text-white"/>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                    <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">

                                                        <div class="container">

                                                            <?php 
                                                                $sqlPostMsg = $conn->query("SELECT * FROM tbl_message where postID = '$post_ID' ");
                                                                $userID = $_SESSION['user_id'];
                                                                
                                                                while($rowMsg = mysqli_fetch_object($sqlPostMsg)){
                                                                    $senderID = $rowMsg->sender; 

                                                                    if($senderID === $userID ){
                                                            ?>
                                                                
                                                                        <div class="message sender">
                                                                            <h5><?php echo $rowMsg->message; ?></h5>
                                                                            <img src="./uploads/<?php echo $_SESSION['pPic']; ?>" class="img-fluid" alt="..." width="50" style="border-radius: 50%;">
                                                                        </div>

                                                            <?php
                                                                    }else if($senderID !== $userID){
                                                                        $sqlSender = $conn->query("Select * from tbl_user where user_id = '$senderID' ");
                                                                        $rowSender = mysqli_fetch_object($sqlSender);
                                                            ?>

                                                                        <div class="message receiver">
                                                                            <img src="./uploads/<?php echo $rowSender->pPic; ?>" class="img-fluid" alt="..." width="50" style="border-radius: 50%;">
                                                                            <h5><?php echo $rowMsg->message; ?></h5>
                                                                        </div>

                                                            <?php
                                                                    }
                                                                }
                                                            ?>

                                                            
                                                        </div>

                                                        <form class="form-horizontal form-material mx-2" action='code.php' method='POST'>
                                                            <div class="form-group">
                                                                <label for="example-email" class="col-md-12">Message Box</label>
                                                                <div class="col-md-12">
                                                                    <input type="text" placeholder="Enter message here ..."
                                                                        class="form-control ps-0 form-control-line" name="msg"
                                                                        id="example-email">
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <div class="col-sm-12 d-flex">
                                                                    <input value="<?php echo $post_ID ?>" type='hidden' name='postID'/>
                                                                    <input value="<?php echo $rowUser->ownerID ?>" type='hidden' name='ownerID'/>
                                                                    
                                                                    <input class="btn btn-success mx-auto mx-md-0 text-white" value='Send' type='submit' name='btnAdopt'/>
                                                                </div>
                                                            </div>
                                                        </form>

                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        <?php }else { ?>

                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="card">
                                            <div class="card-body">
                                                <h4 class="card-title">Post Feed</h4>
                                                    <div class="container-fluid">
                                                        <div class="row">

                                                            <?php 
                                                                $chck_user = $conn->query("SELECT * FROM tbl_post where status = '1' ");
                                                                if($result = mysqli_num_rows($chck_user) > 0){

                                                                    while($row = mysqli_fetch_object($chck_user)){
                                                            ?>
                                                                    <div class="col-lg-4 col-xlg-3 col-md-5">
                                                                        <div class="card">
                                                                            <div class="card-body profile-card">
                                                                                <center class=""> <img src="./uploads/<?php echo $row->pic; ?>"
                                                                                        class="" width="200" />
                                                                                        <form action="code.php" method='POST' class='mt-3'>
                                                                                            <input type="hidden" value="<?php echo $row->postId; ?>" name='viewFeed'>

                                                                                            <input type="submit" value='View Description' name='btnView' class='col-md-12 btn btn-info p-2 text-white'>
                                                                                        </form>
                                                                                </center>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                            <?php  } 

                                                                }else{ ?>

                                                                    <div class="col-lg-12 col-xlg-3 col-md-5">
                                                                        <div class="card ">
                                                                            <div class="card-body profile-card">
                                                                                <input type="text" readonly class='col-md-12 p-5 btn btn-white' value="No Post Yet !" style="font-size: 2rem; width: 100%; border: none;">
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                            <?php } ?>

                                                        </div>
                                                    </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        <?php } unset($_SESSION['viewFeed']); ?>
                    

                </div>
            </div>


            <script src="./assets/plugins/jquery/dist/jquery.min.js"></script>
            <!-- Bootstrap tether Core JavaScript -->
            <script src="./assets/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
            <script src="js/app-style-switcher.js"></script>
            <!--Wave Effects -->
            <script src="js/waves.js"></script>
            <!--Menu sidebar -->
            <script src="js/sidebarmenu.js"></script>
            <!--Custom JavaScript -->
            <script src="js/custom.js"></script>
            <!--This page JavaScript -->
            <!--flot chart-->
            <script src="./assets/plugins/flot/jquery.flot.js"></script>
            <script src="./assets/plugins/flot.tooltip/js/jquery.flot.tooltip.min.js"></script>
            <script src="js/pages/dashboards/dashboard1.js"></script>
        </body>

    <?php } ?>


    </html>
<?php 
	}else{
		?>
			<script>
				alert('<?php echo "Please login first !"; ?>');
				window.location.href="login.php"; 
			</script>                
		<?php
	}
?>