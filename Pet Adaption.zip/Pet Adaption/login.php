<!doctype html>
<html lang="en">
    <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Pet Adaption</title>
</head>

<style>
    .divider:after,
    .divider:before {
        content: "";
        flex: 1;
        height: 1px;
        background: #eee;
    }
    .h-custom {
        height: calc(100% - 73px);
    }
    @media (max-width: 450px) {
        .h-custom {
            height: 100%;
        }
    }
</style>

  <body>

    <section class="vh-100">
        <div class="container-fluid h-custom">
            <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col-md-9 col-lg-6 col-xl-5">
                    <img src="https://logowik.com/content/uploads/images/animal-care-pet91179.logowik.com.webp" class="img-fluid" alt="Sample image">
                </div>
                <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1">
                    <form method='post' action='code.php'>
                        <div class="d-flex flex-row align-items-center justify-content-center justify-content-lg-start">
                            <p class="lead fw-normal mb-0 me-3 fs-2">Welcome User !</p>
                        </div>

                        <div class="divider d-flex align-items-center my-4">
                            <p class="text-center fw-bold mx-3 mb-0"></p>
                        </div>

                        <!-- Email input -->
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" name='user_name' id="floatingInput" placeholder="Enter username">
                            <label for="floatingInput">Enter Username</label>
                        </div>

                        <!-- Password input -->
                        <div class="form-floating mb-3">
                            <input type="password" class="form-control" name='user_pass' id="floatingInput" placeholder="Enter password">
                            <label for="floatingInput">Enter Password</label>
                        </div>

                        <div class="text-center text-lg-start mt-4 pt-2">
                            <input type="submit" name='btn_logIn' value='Login' class="btn btn-primary btn-lg" style="padding-left: 2.5rem; padding-right: 2.5rem;">

                            <p class="small fw-bold mt-2 pt-1 mb-0">Don't have an account? <a href="#!"
                                class="link-danger" data-bs-toggle="modal" data-bs-target="#exampleModal">Register</a></p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
				<form method="POST" action="code.php" enctype="multipart/form-data">
					<div class="modal-body modal-lg">
						<h2 class="text-center">Register Here</h2>
							<div class="row">
								<div class="col-6">
									<input type="text" class="form-control" placeholder="First name" aria-label="First name" name="f_name" required>
								</div>
								<div class="col-6 mb-3">
									<input type="text" class="form-control" placeholder="Middle name" aria-label="Last name" name="m_name" required>
								</div>
								<div class="col-12 mb-3">
									<input type="text" class="form-control" placeholder="Last name" aria-label="First name" name="l_name" required>
								</div>

                                <div class="col-12 mb-3">
									<input type="email" class="form-control" placeholder="Email" aria-label="First name" name="email" required>
								</div>

                                <div class="col-12 mb-3">
									<input type="file" class="form-control" placeholder="frontID" aria-label="First name" name="frontID" required>
								</div>
								</div><div class="col-12 mb-3">
									<input type="file" class="form-control" placeholder="backID" aria-label="First name" name="backID" required>
								</div>

                                <div class="col-12 mb-3">
									<input type="date" class="form-control" placeholder="Birthdate" aria-label="First name" name="bod" required>
								</div>
                                <div class="col-12 mb-3">
									<input type="number" class="form-control" placeholder="Phone Number" aria-label="First name" name="phoneNum" required>
								</div>
                                <div class="col-12 mb-3">
									<input type="text" class="form-control" placeholder="Address" aria-label="First name" name="address" required>
								</div>
                                <hr>
                                <div class="row g-3 align-items-center col-12">
                                    <div class="col-auto">
                                        <label for="inputPassword6" class="col-form-label text-center">Display Picture</label>
                                    </div>
                                    <div class="col-auto">
                                        <input type="file" id="inputPassword6" name="pPic" class="form-control" aria-describedby="passwordHelpInline" required>
                                    </div>
                                </div>
                                <hr>

								<div class="col-12 mb-3">
									<input type="text" class="form-control" placeholder="Username" aria-label="First name" name="user_name" required>
								</div>
								<div class="col-12 mb-3">
									<input type="password" class="form-control" placeholder="Password" aria-label="First name" name="password" required>
								</div>
							</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
						<input type="submit" class="btn btn-primary" value="Submit" name="btn_signUp"/>
					</div>
				</form>
            </div>
        </div>
    </div>

  </body>
</html>