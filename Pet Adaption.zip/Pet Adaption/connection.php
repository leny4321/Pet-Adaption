<?php  

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "pet";

    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // if($conn){
    //     echo "Connection Success !";
    // }else{
    //     echo "Connection Error !";
    // }

?>