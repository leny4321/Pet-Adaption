<?php
include './code.php';

if($_SESSION['user_id']){
	unset($_SESSION['user_id']);
?>
	<!-- redirect to login -->
	<script>
		alert('Successfully Loged out');
		window.location.href="login.php";
	</script> 
	
<?php die; } ?>
