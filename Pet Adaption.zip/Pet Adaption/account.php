<?php 
	include './code.php';

	$userID = $_SESSION['user_id'];
	$chck_user = $conn->query("SELECT * FROM tbl_user WHERE user_id = '$userID' ");
	if($result = mysqli_num_rows($chck_user) > 0){
?>

<!DOCTYPE html>
<html dir="ltr" lang="en">

<?php include './includes/head.php' ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

<body>

    <div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full"
        data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">

        <?php include './includes/header.php'; ?>

        <?php include './includes/sidebar.php'; ?>

        <div class="page-wrapper">
            <div class="page-breadcrumb">
                <div class="row align-items-center">
                    <div class="col-md-6 col-8 align-self-center">
                        <h3 class="page-title mb-0 p-0">Accounts</h3>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Accounts</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="row">

                    <?php
                        if (isset($_SESSION['idUser']) && $_SESSION['idUser'] != '') {
                            $UID = $_SESSION['idUser'];
                            $sqlUser = $conn->query("SELECT * FROM tbl_user WHERE user_id = '$UID' ");
                            $rowUser = mysqli_fetch_object($sqlUser);
                    ?>
                            <div class="row">
                                <div class="col-lg-7 col-xlg-3 col-md-5">
                                    <div class="card">
                                        <div class="card-body profile-card">
                                            <center class=""> <img src="./uploads/<?php echo $rowUser->pPic;?>" class="" width="250" style="border-radius: 50%"/>
                                                <h4 class="card-title mt-2">Display Picture</h4>
                                            </center>
                                        </div>
                                        <hr>
                                        <div class="card-body profile-card">
                                            <center class=""> <img src="./uploads/<?php echo $rowUser->frontID;?>" class="" width="100%" />
                                                <h4 class="card-title mt-2">Front ID</h4>
                                            </center>
                                            <center class="mt-4"> <img src="./uploads/<?php echo $rowUser->backID;?>" class="" width="100%" />
                                                <h4 class="card-title mt-2">Back ID</h4>
                                            </center>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-5 col-xlg-9 col-md-7">
                                    <div class="card">
                                        <div class="card-body">
                                            <form class="form-horizontal form-material mx-2" action='code.php' method='POST'>
                                                <div class="form-group">
                                                    <label class="col-md-12 mb-0">User ID</label>
                                                    <div class="col-md-12">
                                                        <input type="text" readonly placeholder="<?php echo $rowUser->user_id; ?>"
                                                            class="form-control ps-0 form-control-line">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-12 mb-0">Name</label>
                                                    <div class="col-md-12">
                                                        <input type="text" readonly placeholder="<?php echo $rowUser->f_name. ' ' .$rowUser->m_name. ' ' .$rowUser->l_name; ?>"
                                                            class="form-control ps-0 form-control-line">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="example-email" class="col-md-12">Email</label>
                                                    <div class="col-md-12">
                                                        <input type="email" readonly placeholder="<?php echo $rowUser->email; ?>"
                                                            class="form-control ps-0 form-control-line" name="example-email"
                                                            id="example-email">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-12 mb-0">Phone No</label>
                                                    <div class="col-md-12">
                                                        <input type="text" readonly placeholder="<?php echo $rowUser->phoneNum; ?>"
                                                            class="form-control ps-0 form-control-line">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-12 mb-0">Birthday</label>
                                                    <div class="col-md-12">
                                                        <input type="text" readonly placeholder="<?php echo $rowUser->bod; ?>"
                                                            class="form-control ps-0 form-control-line">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="example-email" class="col-md-12">Address</label>
                                                    <div class="col-md-12">
                                                        <input type="email" readonly placeholder="<?php echo $rowUser->address; ?>"
                                                            class="form-control ps-0 form-control-line" name="example-email"
                                                            id="example-email">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-sm-12 d-flex">
                                                        <input value="<?php echo $rowUser->user_id; ?>" type='hidden' name='uID'/>
                                                        
                                                        <input class="btn btn-success mx-auto mx-md-0 text-white" value='Approve' type='submit' name='btnApprove'/>
                                                        <input class="btn btn-danger mx-auto mx-md-2 text-white" value='Decline' type='submit' name='btnDecline'/>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    <?php
                        }else if(isset($_SESSION['viewUser']) && $_SESSION['viewUser'] != ''){
                            $UID = $_SESSION['viewUser'];
                            $sqlUser = $conn->query("SELECT * FROM tbl_user WHERE user_id = '$UID' ");
                            $rowUser = mysqli_fetch_object($sqlUser);
                    ?>
                            <div class="row">
                                <div class="col-lg-7 col-xlg-3 col-md-5">
                                    <div class="card">
                                        <div class="card-body profile-card">
                                            <center class=""> <img src="./uploads/<?php echo $rowUser->pPic;?>" class="" width="250" style="border-radius: 50%"/>
                                                <h4 class="card-title mt-2">Display Picture</h4>
                                            </center>
                                        </div>
                                        <div class="card-body profile-card">
                                            <center class="mt-4"> <img src="./uploads/<?php echo $rowUser->frontID;?>" width="100%" />
                                                <h4 class="card-title mt-2">Front ID</h4>
                                            </center>
                                            <center class="mt-4"> <img src="./uploads/<?php echo $rowUser->backID;?>" width="100%" />
                                                <h4 class="card-title mt-2">Back ID</h4>
                                            </center>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-5 col-xlg-9 col-md-7">
                                    <div class="card">
                                        <div class="card-body">
                                            <form class="form-horizontal form-material mx-2" action='code.php' method='POST'>
                                                <div class="form-group">
                                                    <label class="col-md-12 mb-0">User ID</label>
                                                    <div class="col-md-12">
                                                        <input type="text" readonly placeholder="<?php echo $rowUser->user_id; ?>"
                                                            class="form-control ps-0 form-control-line">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-12 mb-0">Name</label>
                                                    <div class="col-md-12">
                                                        <input type="text" readonly placeholder="<?php echo $rowUser->f_name. ' ' .$rowUser->m_name. ' ' .$rowUser->l_name; ?>"
                                                            class="form-control ps-0 form-control-line">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="example-email" class="col-md-12">Email</label>
                                                    <div class="col-md-12">
                                                        <input type="email" readonly placeholder="<?php echo $rowUser->email; ?>"
                                                            class="form-control ps-0 form-control-line" name="example-email"
                                                            id="example-email">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-12 mb-0">Phone No</label>
                                                    <div class="col-md-12">
                                                        <input type="text" readonly placeholder="<?php echo $rowUser->phoneNum; ?>"
                                                            class="form-control ps-0 form-control-line">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-12 mb-0">Birthday</label>
                                                    <div class="col-md-12">
                                                        <input type="text" readonly placeholder="<?php echo $rowUser->bod; ?>"
                                                            class="form-control ps-0 form-control-line">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="example-email" class="col-md-12">Address</label>
                                                    <div class="col-md-12">
                                                        <input type="email" readonly placeholder="<?php echo $rowUser->address; ?>"
                                                            class="form-control ps-0 form-control-line" name="example-email"
                                                            id="example-email">
                                                    </div>
                                                </div>
                                                <!-- <div class="form-group">
                                                    <div class="col-sm-12 d-flex">
                                                        <input value="<?php echo $rowUser->user_id; ?>" type='hidden' name='uID'/>
                                                        
                                                        <input class="btn btn-success mx-auto mx-md-0 text-white" value='Approve' type='submit' name='btnApprove'/>
                                                        <input class="btn btn-danger mx-auto mx-md-2 text-white" value='Decline' type='submit' name='btnDecline'/>
                                                    </div>
                                                </div> -->
                                            </form>
                                            <button onClick="window.location.reload();" class="btn btn-info mx-auto mx-md-0 text-white">Back</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    <?php
                        }else{
                    ?>	
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title mb-3">Users</h4>
                                        <div class="table-responsive">
                                            
                                            <table id="myTable_1" class="table table-striped">
                                                <thead>
                                                    <tr>
                                                        <th class='p-4'>ID</th>
                                                        <th class='p-4'>Firstname</th>
                                                        <th class='p-4'>Lastname</th>
                                                        <th class='p-4'>Status</th>
                                                        <th class='p-4'>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                <?php

                                                // SQL query
                                                $sql = "SELECT * FROM tbl_user Where user_type = '2' ";
                                                $result = $conn->query($sql);

                                                if ($result->num_rows > 0) {
                                                    while($row = $result->fetch_assoc()) {
                                                        echo "<tr>";
                                                            echo "<td class='p-4'>".$row["user_id"]."</td>";
                                                            echo "<td class='p-4'>".$row["f_name"]."</td>";
                                                            echo "<td class='p-4'>".$row["l_name"]."</td>";
                                                            echo "<td class='p-4'>";
                                                                    if($row['status'] === '1'){
                                                                        echo "Approved";
                                                                    }else if($row['status'] === '0'){
                                                                        echo "Pending";
                                                                    }else{
                                                                        echo "Declined";
                                                                    }
                                                            echo "</td>";
                                                            echo "<td class='p-4'>";
                                                                    if($row['status'] === '1'){
                                                ?>
                                                                        <form action='code.php' method='POST'>
                                                                            <input type='hidden' value="<?php echo $row["user_id"]; ?>" name='viewUser'>

                                                                            <input type='submit' value='View User' name='btnViewUser' class='col-md-6 btn btn-success p-2 text-white'>
                                                                        </form>
                                                <?php
                                                                    }else if($row['status'] === '0'){
                                                ?>
                                                                        <form action='code.php' method='POST'>
                                                                            <input type='hidden' value="<?php echo $row["user_id"]; ?>" name='userID'>

                                                                            <input type='submit' value='View Pending Application' name='btnAction' class='col-md-6 btn btn-danger p-2 text-white'>
                                                                        </form>
                                                <?php
                                                                    }else{
                                                                        echo "Declined";
                                                                    }
                                                            echo "</td>";
                                                        echo "</tr>";
                                                    }
                                                }
                                                ?>
                                                </tbody>
                                            </table> 
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                    <?php }unset($_SESSION['viewUser']); unset($_SESSION['idUser']); ?>
                </div>
            </div>
        </div>
        
    </div>
    


    <script src="./assets/plugins/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="./assets/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/app-style-switcher.js"></script>
    <!--Wave Effects -->
    <script src="js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="js/custom.js"></script>

    <link href="https://cdn.datatables.net/1.13.3/css/jquery.dataTables.min.css"  rel='stylesheet'>
    <script src="https://cdn.datatables.net/1.13.3/js/jquery.dataTables.min.js"></script>  

    <script>
        $(document).ready(function () {
            $('#printRequest').DataTable();
        });

        $('#exampleModal').modal("show");
            $('#cancel').click(function() {
                $('#exampleModal').modal("hide");
        });
    </script>

    <script>
        $(document).ready(function() {
            $('#myTable_1').DataTable();
        });
    </script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-sQ9/dqbTdlYEXjXtE8pO83IzXuQNwhJTJ0qosDw0it4cq9UnCGrqy7h4cjpGV8uT" crossorigin="anonymous"></script>
    
</body>

</html>

<?php 
	}else{
		?>
			<script>
				alert('<?php echo "Please login first !"; ?>');
				window.location.href="login.php"; 
			</script>                
		<?php
	}
?>