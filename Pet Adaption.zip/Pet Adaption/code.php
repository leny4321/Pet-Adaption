<?php 

session_start();
include 'connection.php';


    // Login
    if(isset($_POST['btn_logIn'])){
        $username = $_POST['user_name'];
        $password = $_POST['user_pass'];

            //read from database
            $query_admin = "SELECT * FROM tbl_user WHERE username = '$username' AND status = '1' ";
            $result_admin = mysqli_query($conn, $query_admin);

            if(mysqli_num_rows($result_admin) > 0){
                $user_data = mysqli_fetch_assoc($result_admin);
                $password_dec = $user_data['password'];

                $veryfy = password_verify($password, $password_dec);

                if($veryfy){
                    $_SESSION['user_id'] = $user_data['user_id'];
                    $_SESSION['user_type'] = $user_data['user_type'];
                    $_SESSION['userName'] = $user_data['username'];
                    $_SESSION['bod'] = $user_data['bod'];
                    $_SESSION['phoneNum'] = $user_data['phoneNum'];
                    $_SESSION['email'] = $user_data['email'];
                    $_SESSION['address'] = $user_data['address'];
                    $_SESSION['pPic'] = $user_data['pPic'];
                        
                    $_SESSION['user_fname'] = $user_data['f_name'] ." ". $user_data['m_name'] ." ". $user_data['l_name'];

                    $login_success = "Message          :        Welcome  " . $_SESSION['user_fname'];
                    ?>
                        <script>
                            alert('<?php echo $login_success; ?>');
                            window.location.href="index.php";
                        </script>  
                    <?php
                    
                }else{
                    $login_error = "Username or Password Incorrect!";
                    ?>
                        <script>
                            alert('<?php echo $login_error; ?>');
                            window.location.href="login.php";
                        </script>                
                    <?php

                }
                    
            }else{
                $login_error = "Username or Password Incorrect!";
                ?>
                    <script>
                        alert('<?php echo $login_error; ?>');
                        window.location.href="login.php";
                    </script>                
                <?php

            }
    }
    // Login


    // REG USER
    if(isset($_POST['btn_signUp'])){

        $f_name = $_POST['f_name'];
        $l_name = $_POST['l_name'];
        $m_name = $_POST['m_name'];
        $username = $_POST['user_name'];
        $password = $_POST['password'];

        $bod = $_POST['bod'];
        $address = $_POST['address'];
        $email = $_POST['email'];
        $phoneNum = $_POST['phoneNum'];

        $query_user = $conn->query("SELECT * FROM tbl_user WHERE f_name = '$f_name' AND l_name = '$l_name' ");
        $query_row = mysqli_num_rows($query_user);	

        if($query_row >= 1){
            $acc_err = "Message                :        Account already exist !";
                ?>
                    <script>
                        alert('<?php echo $acc_err; ?>');
                        window.location.href="login.php";
                    </script>  
                <?php 

        }elseif($query_row <= 1){

            $hash_password = password_hash($password, PASSWORD_DEFAULT);
            $user_id = rand(100000,999999);

            $frontID = $_FILES['frontID']['name'];
			$backID = $_FILES['backID']['name'];
			$pPic = $_FILES['pPic']['name'];

            if($frontID != '' && $backID != '' && $pPic != ''){
                $ext_1 = pathinfo($frontID, PATHINFO_EXTENSION);
                $allowed = ['jpeg', 'png', 'jpg'];
            
                //check if file type is valid
                if (in_array($ext_1, $allowed)){
                    $path = 'uploads/';
                        
                    move_uploaded_file($_FILES['frontID']['tmp_name'],($path . $frontID));
                    move_uploaded_file($_FILES['backID']['tmp_name'],($path . $backID));
                    move_uploaded_file($_FILES['pPic']['tmp_name'],($path . $pPic));
                    
                    // insert file details into database
                    $query_insertReg = $conn->query("INSERT INTO tbl_user
                                                                (user_id, pPic, f_name, m_name, l_name, bod, 
                                                                email, address, phoneNum, username, password, 
                                                                user_type, status, frontID, backID) 
                                                                VALUES 
                                                                ('$user_id', '$pPic', '$f_name', '$m_name', '$l_name', '$bod', 
                                                                '$email', '$address', '$phoneNum', '$username', '$hash_password', 
                                                                '2', '0', '$frontID', '$backID')");

                    if($query_insertReg){
                        ?>
                            <script>
                                alert('<?php echo "Account On Review !"; ?>');
                                window.location.href="login.php"; 
                            </script>                
                        <?php
                    }else{
                        ?>
                            <script>
                                alert('<?php echo "Registration Failed !"; ?>');
                                window.location.href="login.php"; 
                            </script>                
                        <?php
                    }


                }else{
                    ?>
                        <script>
                            alert('<?php echo "Account error !"; ?>');
                            window.location.href="login.php"; 
                        </script>                
                    <?php
                }
            }
            
        }

    }
    // REG USER


    // REQ POST
    if(isset($_POST['btn_reqPost'])){

        $owerName = $_POST['owerName'];
        $petName = $_POST['petName'];
        $bod = $_POST['bod'];
        $description = $_POST['description'];
        $petPic = $_POST['petPic'];
        $ownerID = $_SESSION['user_id'];
        $vacc = $_POST['vacc'];

        $userID = $_SESSION['user_id'];

        $query_user = $conn->query("SELECT * FROM tbl_post WHERE petName = '$petName' AND status = '1' ");
        $query_row = mysqli_num_rows($query_user);	

        if($query_row >= 1){
            $acc_err = "Message                :        Post already exist !";
                ?>
                    <script>
                        alert('<?php echo $acc_err; ?>');
                        window.location.href="post.php";
                    </script>  
                <?php 

        }elseif($query_row <= 1){

            $post_id = rand(100000,999999);

            date_default_timezone_set('Asia/Manila');
            $date = date('Y-m-d');

			$petPic = $_FILES['petPic']['name'];
			$petCert = $_FILES['petCert']['name'];

            if($petPic != '' && $petCert != ''){
                $ext_1 = pathinfo($petPic, PATHINFO_EXTENSION);
                $allowed = ['jpeg', 'png', 'jpg'];
            
                //check if file type is valid
                if (in_array($ext_1, $allowed)){
                    $path = 'uploads/';
                        
                    move_uploaded_file($_FILES['petPic']['tmp_name'],($path . $petPic));
                    move_uploaded_file($_FILES['petCert']['tmp_name'],($path . $petCert));
                    
                    // insert file details into database
                    $query_insertReg = $conn->query("INSERT INTO tbl_post
                                                    (postId, petName, owner, ownerID, bod, date, pic, description, status, vacc, petCert)
                                                    VALUES 
                                                    ('$post_id', '$petName', '$owerName', '$ownerID', '$bod', '$date', '$petPic', '$description', '4', '$vacc', '$petCert')");

                    if($query_insertReg){
                        $acc_success = "Message                :        Post on review !";
                        ?>
                            <script>
                                alert('<?php echo $acc_success; ?>');
                                window.location.href="post.php";
                            </script>  
                        <?php 
                    }else{
                        $acc_success = "Message                :        Post error !";
                        ?>
                            <script>
                                alert('<?php echo $acc_success; ?>');
                                window.location.href="post.php"; 
                            </script>                
                        <?php
                    }


                }else{
                    ?>
                        <script>
                            alert('<?php echo "Picture error !"; ?>');
                            window.location.href="post.php"; 
                        </script>                
                    <?php
                }
            }
            
        }

    }
    // REQ POST



    // APPROVE ACCOUNT
	if(isset($_POST['btnApprove'])){
		$uID = $_POST['uID'];

		$update = $conn->query("UPDATE tbl_user 
		SET status = '1' WHERE user_id = '$uID' ");

		$success = "Message          :        User Approved !";
		?>
			<script>
				alert('<?php echo $success; ?>');
				window.location.href="account.php";
			</script>  
		<?php
	}
    // APPROVE ACCOUNT


    // DECLINE ACCOUNT
	if(isset($_POST['btnDecline'])){
		$uID = $_POST['uID'];

		$update = $conn->query("UPDATE tbl_user 
		SET status = '3' WHERE user_id = '$uID' ");

		$success = "Message          :        User Declined !";
		?>
			<script>
				alert('<?php echo $success; ?>');
				window.location.href="account.php";
			</script>  
		<?php
	}
    // DECLINE ACCOUNT


    // VIEW USER
    if(isset($_POST['btnAction'])){
        $_SESSION['idUser'] = $_POST['userID'];
        header("location:account.php" );
    }
    // VIEW USER
    
    // VIEW USER
    if(isset($_POST['btnViewUser'])){
        $_SESSION['viewUser'] = $_POST['viewUser'];
        header("location:account.php" );
    }
    // VIEW USER




    // VIEW POST REQ
    if(isset($_POST['btnPostReq'])){
        $_SESSION['postID'] = $_POST['postID'];
        header("location:post.php" );
    }
    // VIEW POST REQ

    // VIEW POST REQ
    if(isset($_POST['btnViewPost'])){
        $_SESSION['viewPost'] = $_POST['viewPost'];
        header("location:post.php" );
    }
    // VIEW POST REQ




    // APPROVE POST
	if(isset($_POST['btnApprove_post'])){
		$pid = $_POST['pid'];

		$update = $conn->query("UPDATE tbl_post 
		SET status = '1' WHERE postId = '$pid' ");

		$success = "Message          :        Post Approved !";
		?>
			<script>
				alert('<?php echo $success; ?>');
				window.location.href="post.php";
			</script>  
		<?php
	}
    // APPROVE POST



    // DECLINE POST
	if(isset($_POST['btnDecline_post'])){
		$pid = $_POST['pid'];

		$update = $conn->query("UPDATE tbl_post 
		SET status = '5' WHERE postId = '$pid' ");

		$success = "Message          :        Post Declined !";
		?>
			<script>
				alert('<?php echo $success; ?>');
				window.location.href="post.php";
			</script>  
		<?php
	}
    // DECLINE POST
    

    
    // VIEW POST 
    if(isset($_POST['btnView'])){
        $_SESSION['viewFeed'] = $_POST['viewFeed'];
        header("location:index.php" );
    }
    // VIEW POST


    // VIEW ADOPT MESSAGE OWNER
    if(isset($_POST['btnAdopt'])){
        $postID = $_POST['postID'];
        $msg = $_POST['msg'];
        $sender = $_SESSION['user_id'];

        $sqlOwner = $conn->query("SELECT * FROM tbl_post WHERE postId = '$postID' ");
        $rowOwner = mysqli_fetch_object($sqlOwner);
        $owner = $rowOwner->owner;

        $reciever = $_POST['ownerID'];

        $msgID = rand(100000,999999);

        date_default_timezone_set('Asia/Manila');
        $date = date('Y-m-d');

        $sqlMsg = $conn->query("INSERT INTO `tbl_message`(`sender`, `reciever`, `msgID`, `postID`, `message`, `date`, `owner`) VALUES ('$sender','$reciever','$msgID','$postID','$msg','$date','$owner')");
        
        if($sqlMsg){
            ?>
                <script>
                    alert('<?php echo "Message Sent !"; ?>');
                    window.location.href="index.php";
                </script>                
            <?php
        }else{
            ?>
                <script>
                    alert('<?php echo "Message Error !"; ?>');
                    window.location.href="index.php";
                </script>                
            <?php
        }



    }
    // VIEW ADOPT MESSAGE OWNER

    

    // POST HIDE OR SHOW
    if(isset($_POST['btnPostUpdate'])){
        $postoUpdate = $_POST['postoUpdate'];
        $postStat = $_POST['postStat'];

        if($postStat === '3'){

            $sqlUp = $conn->query("UPDATE `tbl_post` SET status = '3' WHERE postId = '$postoUpdate' ");

            if($sqlUp){
                ?>
                    <script>
                        alert('<?php echo "Post Updated !"; ?>');
                        window.location.href="post.php";
                    </script>                
                <?php
            }else{
                ?>
                    <script>
                        alert('<?php echo "Post Update Error !"; ?>');
                        window.location.href="post.php";
                    </script>                
                <?php
            }

        }else if($postStat === '1'){

            $sqlUp = $conn->query("UPDATE `tbl_post` SET status = '1' WHERE postId = '$postoUpdate' ");

            if($sqlUp){
                ?>
                    <script>
                        alert('<?php echo "Post Updated !"; ?>');
                        window.location.href="post.php";
                    </script>                
                <?php
            }else{
                ?>
                    <script>
                        alert('<?php echo "Post Update Error !"; ?>');
                        window.location.href="post.php";
                    </script>                
                <?php
            }
        }else{
            ?>
                <script>
                    alert('<?php echo "Post Update Error !"; ?>');
                    window.location.href="post.php";
                </script>                
            <?php
        }

        




    }
    // POST HIDE OR SHOW
?>