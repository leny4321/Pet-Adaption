        <header class="topbar" data-navbarbg="skin6">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                <div class="navbar-header" data-logobg="skin6">
                    <a class="navbar-brand" href="index.php">
                        <span class="logo-text d-flex justify-content-center" style="width: 100%;">
                            <div class="col-md-12 col-lg-6 col-xl-5" style="width: 100px;">
                                <img src="https://logowik.com/content/uploads/images/animal-care-pet91179.logowik.com.webp"
                                class="img-fluid" alt="Sample image">
                            </div>
                        </span>
                    </a>
                    <a class="nav-toggler waves-effect waves-light text-dark d-block d-md-none"
                        href="javascript:void(0)"><i class="ti-menu ti-close"></i></a>
                </div>
                <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin5"> 
                    <ul class="navbar-nav me-auto mt-md-0 ">
                        <li class="nav-item hidden-sm-down">
                            <form class="ps-3">
                                <style>
                                    #title{
                                        border: 0px;
                                        background: transparent;
                                        color: white;
                                    }
                                </style>
                                <input type="text" id='title' readonly class="form-control fs-2" value='Pet Adaption'> 
                            </form>
                        </li>
                    </ul>
                    <ul class="navbar-nav">
                        <li class="nav-item dropdown">
                            <!-- <a class="nav-link dropdown-toggle waves-effect waves-dark" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <img src="./assets/images/users/1.jpg" alt="user" class="profile-pic me-2"><?php echo $_SESSION['user_fname']; ?>
                            </a> -->
                            <a class="nav-link dropdown-toggle waves-effect waves-dark" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <?php echo $_SESSION['user_fname']; ?>
                            </a>
                            <ul class="dropdown-menu show" aria-labelledby="navbarDropdown"></ul>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>