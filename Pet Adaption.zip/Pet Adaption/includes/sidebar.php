<?php 

    $user_type = $_SESSION['user_type'];
    if($user_type === '1'){
?>
        
        <aside class="left-sidebar" data-sidebarbg="skin6">
            <div class="scroll-sidebar">
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">

                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="index.php" aria-expanded="false"><i class="me-3 far fa-clock fa-fw"
                                    aria-hidden="true"></i><span class="hide-menu">Dashboard</span></a></li>

                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="post.php" aria-expanded="false">
                                <i class="me-3 fa fa-list" aria-hidden="true"></i><span
                                    class="hide-menu">Post to Approve</span></a>
                        </li>

                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="account.php" aria-expanded="false">
                                <i class="me-3 fa fa-list" aria-hidden="true"></i><span
                                    class="hide-menu">Account</span></a>
                        </li>

                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="settings.php" aria-expanded="false"><i class="me-3 fa fa-cog"
                                    aria-hidden="true"></i><span class="hide-menu">Settings</span></a>
                        </li>

                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="logout.php" aria-expanded="false"><i class="me-3 fa fa-arrow-left"
                                    aria-hidden="true"></i><span class="hide-menu">Log out</span></a>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>

<?php }else if($user_type === '2'){ ?>

        <aside class="left-sidebar" data-sidebarbg="skin6">
            <div class="scroll-sidebar">
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">

                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="index.php" aria-expanded="false"><i class="me-3 far fa-clock fa-fw"
                                    aria-hidden="true"></i><span class="hide-menu">Dashboard</span></a></li>

                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="post.php" aria-expanded="false">
                                <i class="me-3 fa fa-list" aria-hidden="true"></i><span
                                    class="hide-menu">Post to Status</span></a>
                        </li>

                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="userSettings.php" aria-expanded="false"><i class="me-3 fa fa-cog"
                                    aria-hidden="true"></i><span class="hide-menu">Settings</span></a>
                        </li>

                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="logout.php" aria-expanded="false"><i class="me-3 fa fa-arrow-left"
                                    aria-hidden="true"></i><span class="hide-menu">Log out</span></a>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>

<?php } ?>